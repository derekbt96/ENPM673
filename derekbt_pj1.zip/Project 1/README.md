# ENPM673
ENPM673 Projects

To run program run main.py under Code with python 3 with current opencv and numpy

To change the video that is processed uncomment the desired video to open in lines 26-29 under main.py

To change if the cube, encoding, or Lena is added, toggle the corresponding booleans in lines 33/34/35 in main.py

The video files were too big to be added to the folder so the videos need to added into the Code directory before the code can be run.
