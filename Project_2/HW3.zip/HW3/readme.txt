Run the file "main_final.py" as "python main_final.py". The challenge video and the night video need to be in the folder for this to run.

For the output of the first task, uncomment lines 38 and 39 in the code. And comment lines 43 and 44.
